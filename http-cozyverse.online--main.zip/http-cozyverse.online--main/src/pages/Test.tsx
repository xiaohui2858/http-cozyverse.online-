<<<<<<< HEAD
import React from 'react';

const Test: React.FC = () => {
  return (
    <div style={{ padding: '20px', backgroundColor: 'red', color: 'white', fontSize: '24px' }}>
      <h1>TEST PAGE - This should be visible!</h1>
      <p>If you can see this, React is working!</p>
    </div>
  );
};

=======
import React from 'react';

const Test: React.FC = () => {
  return (
    <div style={{ padding: '20px', backgroundColor: 'red', color: 'white', fontSize: '24px' }}>
      <h1>TEST PAGE - This should be visible!</h1>
      <p>If you can see this, React is working!</p>
    </div>
  );
};

>>>>>>> ec9fcde8d87b7a21fa7a23217a6003369e93c4f3
export default Test; 